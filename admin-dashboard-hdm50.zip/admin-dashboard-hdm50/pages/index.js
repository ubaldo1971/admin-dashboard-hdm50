import AdminDashboard from "../components/AdminDashboard";
export default function Home() {
  return <AdminDashboard />;
}
